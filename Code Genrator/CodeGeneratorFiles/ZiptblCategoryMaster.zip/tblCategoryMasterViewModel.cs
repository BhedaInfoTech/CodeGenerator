using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace tblCategoryMasterViewModel
 {
public class tblCategoryMasterViewModel
 {
  public tblCategoryMasterViewModel()
  {
Friendly_Message = new List<FriendlyMessageInfo>();
Pager = new PaginationInfo();
 tblcategorymaster = new tblCategoryMasterInfo();
 tblcategorymasters = new List<tblCategoryMasterInfo>();
  }
public List<FriendlyMessageInfo> Friendly_Message { get; set; }
public PaginationInfo Pager { get; set; }
public tblCategoryMasterInfo tblcategorymaster { get; set; }
public List<tblCategoryMasterInfo> tblcategorymasters { get; set; }
  }
} 