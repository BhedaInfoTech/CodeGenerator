
Create Procedure Get_tblCategoryMaster
(
)
as
begin
Select Id, Name, Active, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn 
 from tblCategoryMaster
end