
tblCategoryMaster: { 

Id : $('#txtId').val(),

Name : $('#txtName').val(),

Active : $('#txtActive').val(),

 }