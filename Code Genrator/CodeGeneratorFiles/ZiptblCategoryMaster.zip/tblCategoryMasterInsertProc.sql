Create Procedure Insert_tblCategoryMaster
(
@Name nvarchar(100),
@Active bit,
@CreatedBy int,
@CreatedOn datetime,
@UpdatedBy int,
@UpdatedOn datetime
)
as
begin
Insert into tblCategoryMaster
(
Name,
Active,
CreatedBy,
CreatedOn,
UpdatedBy,
UpdatedOn
)
values
(
@Name,
@Active,
@CreatedBy,
@CreatedOn,
@UpdatedBy,
@UpdatedOn
)
end