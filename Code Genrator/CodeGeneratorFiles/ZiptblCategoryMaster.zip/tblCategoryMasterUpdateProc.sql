Create Procedure Update_tblCategoryMaster
(
@Id int,
@Name nvarchar(100),
@Active bit,
@UpdatedBy int,
@UpdatedOn datetime
)
as
begin
Update tblCategoryMaster Set 
 Name = @Name ,
 Active = @Active ,
 UpdatedBy = @UpdatedBy ,
 UpdatedOn = @UpdatedOn
Where Id = @Id
end