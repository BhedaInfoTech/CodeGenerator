using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace tblCategoryMasterRepo
 {
public class tblCategoryMasterRepo
 {

  SQLHelperRepo _sqlRepo;

  public tblCategoryMasterRepo()
  {
   _sqlRepo = new SQLHelperRepo();
  }

  public void Insert_tblCategoryMaster(tblCategoryMasterInfo tblcategorymaster)
  {
   _sqlRepo.ExecuteNonQuery(SetValues_In_tblCategoryMaster(tblcategorymaster), StoredProcedures.Insert_tblCategoryMaster.ToString(), CommandType.StoredProcedure);
  }

  public void Update_tblCategoryMaster(tblCategoryMasterInfo tblcategorymaster)
  {
   _sqlRepo.ExecuteNonQuery(Set_Values_In_tblCategoryMaster(tblcategorymaster), StoredProcedures.Update_tblCategoryMaster.ToString(), CommandType.StoredProcedure);
  }

  private List<SqlParameter> Set_Values_In_tblCategoryMaster(tblCategoryMasterInfo tblcategorymaster)
  {
   List<SqlParameter> sqlParams = new List<SqlParameter>();
   sqlParams.Add(new SqlParameter("@Id",tblcategorymaster.Id));
   sqlParams.Add(new SqlParameter("@Name",tblcategorymaster.Name));
   sqlParams.Add(new SqlParameter("@Active",tblcategorymaster.Active));
   sqlParams.Add(new SqlParameter("@CreatedBy",tblcategorymaster.CreatedBy));
   sqlParams.Add(new SqlParameter("@CreatedOn",tblcategorymaster.CreatedOn));
   sqlParams.Add(new SqlParameter("@UpdatedBy",tblcategorymaster.UpdatedBy));
   sqlParams.Add(new SqlParameter("@UpdatedOn",tblcategorymaster.UpdatedOn));
   return sqlParams;
  }

  public List<tblCategoryMasterInfo> Get_tblCategoryMasters(ref PaginationInfo pager)
  {
   List<tblCategoryMasterInfo> tblcategorymasters = new List<tblCategoryMasterInfo>();
   DataTable dt = _sqlRepo.ExecuteDataTable(null, StoredProcedures.Get_tblCategoryMaster.ToString(), CommandType.StoredProcedure);
   foreach (DataRow dr in CommonMethods.GetRows(dt, ref pager))
   {
    tblcategorymasters.Add(Get_tblCategoryMaster_Values(dr));
   }
    return tblcategorymasters;
 }

  public tblCategoryMasterInfo Get_tblCategoryMaster_By_Id (int tblcategorymasterId)
  {
   List<SqlParameter> sqlParams = new List<SqlParameter>();
   tblCategoryMasterInfo tblcategorymaster = new tblCategoryMasterinfo();
   sqlParams.Add(new SqlParameter("@Id",tblcategorymasterId));
   DataTable dt = _sqlRepo.ExecuteDataTable(sqlParams, StoredProcedures.Get_tblCategoryMaster_By_Id.ToString(), CommandType.StoredProcedure);
   List<DataRow> drList = new List<DataRow>();
   drList = dt.AsEnumerable().ToList();
   foreach (DataRow dr in drList)
   {
    tblcategorymaster= Get_tblCategoryMaster_Values(dr);
   }
    return tblcategorymaster;
 }
 
  private tblCategoryMasterInfo Get_tblCategoryMaster_Values(DataRow dr)
 {
   tblCategoryMasterInfo tblcategorymaster = new tblCategoryMasterInfo();
 
   tblcategorymaster.Id = Convert.ToInt32(dr["Id"]);
   tblcategorymaster.Name = Convert.ToString(dr["Name"]);
   tblcategorymaster.Active = Convert.ToBoolean(dr["Active"]);
   tblcategorymaster.CreatedBy = Convert.ToInt32(dr["CreatedBy"]);
   tblcategorymaster.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
   tblcategorymaster.UpdatedBy = Convert.ToInt32(dr["UpdatedBy"]);
   tblcategorymaster.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
   return tblcategorymaster;
 }

  public void Delete_tblCategoryMaster_By_Id(int tblcategorymasterId)
{
   List<SqlParameter> sqlParams = new List<SqlParameter>();
   sqlParams.Add(new SqlParameter("@Id", tblcategorymasterId));
   _sqlRepo.ExecuteNonQuery(sqlParams, StoredProcedures.Delete_tblCategoryMaster_By_Id.ToString(), CommandType.StoredProcedure);
 }

 }
} 