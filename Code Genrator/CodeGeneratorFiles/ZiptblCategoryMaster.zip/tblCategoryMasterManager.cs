using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace tblCategoryMasterManager
 {
public class tblCategoryMasterManager
 {

  tblCategoryMasterRepo _tblcategorymasterRepo;

  public tblCategoryMasterManager()
  {
  _tblcategorymasterRepo = new tblCategoryMasterRepo();
  }

  public void Insert_tblCategoryMaster(tblCategoryMasterInfo tblcategorymaster)
  {
  _tblcategorymasterRepo.Insert_tblCategoryMaster(tblcategorymaster);
  }

  public void Update_tblCategoryMaster(tblCategoryMasterInfo tblcategorymaster)
  {
  _tblcategorymasterRepo.Update_tblCategoryMaster(tblcategorymaster);
  }

  public List<tblCategoryMasterInfo> Get_tblCategoryMasters(ref PaginationInfo pager)
  {
  return _tblcategorymasterRepo.Get_tblCategoryMasters(ref pager);
  }

  public tblCategoryMasterInfo Get_tblCategoryMaster_By_Id (int tblcategorymasterId)
  {
  return _tblcategorymasterRepo.Get_tblCategoryMaster_By_Id(tblcategorymasterId);
  }

  public void Delete_tblCategoryMaster_By_Id(int tblcategorymasterId)
 {
 _enquiryRepo.Delete_tblCategoryMaster_By_Id(tblcategorymasterId);
 }
 }
} 