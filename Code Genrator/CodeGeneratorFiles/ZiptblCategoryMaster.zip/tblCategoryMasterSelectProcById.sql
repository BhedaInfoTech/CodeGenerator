
Create Procedure Get_tblCategoryMaster_By_Id
(
@Id int
)
as
begin
Select Id, Name, Active, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn 
 from tblCategoryMaster
 where  Id = @Id
end