
Create Procedure Delete_tblCategoryMaster_By_Id
(
@Id int
)
as
begin
 Delete from tblCategoryMaster
 Where Id = @Id
end