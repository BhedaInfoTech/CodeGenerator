
tblUserMaster: { 

Id : $('#txtId').val(),

UserName : $('#txtUserName').val(),

Password : $('#txtPassword').val(),

Linkedwith : $('#txtLinkedwith').val(),

Active : $('#txtActive').val(),

 }